import java.util.Scanner;
public class Integradora{
	public static void main(String[] args) {
		System.out.println("Bienvenido a la calculadora de Genshin Impact \n (1). Calcular daño \n (2). Historial ultimos 10");
		int menu, select, nivel, tiporeaccion;
		double maestriaelemental, probdañocrit, dañoporcent;
		Scanner entrada = new Scanner(System.in);
		menu= entrada.nextInt();
		if (menu==1) {
			System.out.println("Que quieres ingresar: \n(1). Un personaje \n(2). Un equipo");
			select= entrada.nextInt();
			if (select==1) {
				 System.out.println("Ingresa el nivel del personaje");
           	        nivel=entrada.nextInt();
           	     System.out.println("Ingresa la maestria elemental del personaje");
           	     	maestriaelemental=entrada.nextInt();
           	     System.out.println("Ingresa la probabilidad de daño critico");
           	     	probdañocrit=entrada.nextInt();
           	     System.out.println("Ingresa la cantidad de daño porcentual");
           	     	dañoporcent=entrada.nextInt();
           	     System.out.println("Tipo de reaccion");
           	        System.out.println("(1). Reaccion Transformativa");
           	        System.out.println("(2). Reaccion Amplificativa");
           	        System.out.println("(3). Reaccion Aditiva");
           	        tiporeaccion=entrada.nextInt();
			}
		}else{
			if (menu==2) {
				System.out.println("Aun no hay un historial de 10 personajes");
			}
		}
	}
}